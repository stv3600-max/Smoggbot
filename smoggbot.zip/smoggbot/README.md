# Smoggbot

Classic machine learning algorithms implemented **from scratch with NumPy** —
no scikit-learn. Built as an academic project to demonstrate how these
algorithms actually work under the hood.

## What's inside

| Module | Algorithm | Approach |
|---|---|---|
| `linear_regression` | Ordinary least squares regression | Closed-form normal equation via `lstsq` |
| `knn` | k-Nearest Neighbours classifier | Vectorised Euclidean distances, majority vote |
| `kmeans` | k-Means clustering | Lloyd's algorithm with seeded random init |
| `metrics` | Accuracy, precision, recall, F1, confusion matrix, MSE, R² | — |
| `datasets` | Synthetic data generators + train/test split | Gaussian blobs, linear data |

## Project structure

```
smoggbot/
├── src/smoggbot/         # the library
├── examples/demo.py     # end-to-end demo of all three models
├── tests/test_models.py # unit tests (stdlib unittest, no extra deps)
├── requirements.txt
└── README.md
```

## Quickstart

```bash
# 1. (optional) create a virtual environment
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate

# 2. install the only dependency
pip install -r requirements.txt

# 3. run the demo
python examples/demo.py

# 4. run the tests
python -m unittest discover -s tests -v
```

## Example

```python
import sys
sys.path.insert(0, "src")

from smoggbot import KNNClassifier, datasets, metrics

X, y = datasets.make_classification(n_samples=400, n_classes=3, random_state=7)
X_train, X_test, y_train, y_test = datasets.train_test_split(X, y, random_state=7)

model = KNNClassifier(k=5).fit(X_train, y_train)
print("accuracy:", metrics.accuracy_score(y_test, model.predict(X_test)))
```

## Theory notes

- **Linear regression** minimises the sum of squared residuals; the normal
  equation gives the exact minimiser when `XᵀX` is invertible.
- **k-NN** is a *lazy learner*: training is just memorisation, all the work
  happens at prediction time. Small `k` overfits noise, large `k` over-smooths.
- **k-Means** alternates between assigning points to the nearest centroid and
  recomputing centroids as cluster means, monotonically decreasing inertia.

## Author

Omotayo — personal academic project.
